#######################################################################################################
# Name: globalfunctions.ps1
# Description: A set of useful powershell functions to use in other powershell scripts
# Author: Michael Rueefli (michael@miru.ch)
# Thanks for ideas and snippetd to: Hagen Frank, Tobias Weltner, Joel Bennett
# date 2008 - 2011
# Usage: To use the functions on other scripts include the globalfunctions.ps1 in your custom script.
#		 . c:\admin\scripts\globalfunctions.ps1
#
# Changelog: 0.2 / 29.12.2008 / Added backward compatibility to WSH scripting,  Added functions: dirsize, sqlquery
#			 0.3 / 01.01.2009 / Added functions: psexec, checkprocs, checksvc
#            0.4 / 13.02.2009 / Added functions: Dirwatcher, EvtListener, convertTOBase64, convertFROMbase64
#			 0.5 / 14.04.2009 / Added functions: Read-HostMasked
#			 0.6 / 06.05.2009 / Fixed Bug in Deloldfiles where no Fileextension specified
#			 0.7 / 11.05.2009 / Added two functions for SID to NTAccounct conversion
#			 0.8 / 01.07.2009 / Extended sendmail function to allow attachments
#			 0.9 / 07.09.2009 / Added makegroup and makepasswd functions to support cygwin installation in high secure AD environments
#			 0.91/ 10.09.2009 / Corrected Bug in makepasswd for local users
#			 0.92/ 13.07.2010 / Fixed Bug in sqlquery function where sql command was not SELECT
#			 0.93/ 28.07.2010 / Fixed deloldfiles (function deletes now folders too)
#			 0.94/ 29.07.2010 / Fixed deloldfiles (function deletes folders without confirm)
#			 0.95  25.11.2010 / Added Find / Replace Function to modify text files
#			 0.96/ 03.12.2010 / Extand Find/Replace Function 
#			 0.97/ 17.12.2010 / Renew dirsize function
#			 0.98/ 21.01.2011 / Added two functions for certificates import (Import-509Certificate and Import-PfxCertificate)
#			 0.99/ 21.01.2011 / Updated WriteEvent function (removed confirmation dialog when source is missing in EVTLOG)
#			 1.00/ 08.05.2011 / Added ExportPFX function to export PKCS12 certificates
#	
$Globalfunctionversion = 1.00	# current Version
#######################################################################################################

#######################################################################################################
# Included Functions																				  #
#######################################################################################################
# Function Name:		Description:
# --------------		-------------------------------------------------------------------------------
# checkprocs			(function to query for processes beeing in running state)
# checksvc				(function to check for services beeing in running state)
# convertToBase64		(function to convert a string to a base64 encrypted value)
# convertFromBase64		(function to convert a base64 encrypted value back to cleartext)
# ConvertToSid			(function to convert a NTAccount to SID (get the SID of a local or domain account or group)
# ConvertToNtAccount	(function to convert a SID back to the matching account or group)
# deloldfiles 			(function to cleanup files older x days recursivly)
# dirsize 				(function to enum directory sizes on disk)
# dirwatcher			(function to watch a directory for changes : -->Experimental only!)
# exportPFX				(function to export certificates including private key to PKCS12 format)
# findreplace			(powerful find / replace funtion including coding settings)
# getadmin 				(check if current user is admin)
# Import-509Certificate (Import a Std x509 certificate)
# Import-PFXCertificate (Import a PXCS12 certificate)
# makegroup				(add a new group to Cygwin group file)
# makepasswd			(add a new user to Cygwin passwd file)
# psexec				(run external programs. function has additional options)
# try 					(classic .NET Errorhandling -> try,catch,finally)
# Read-HostMasked		(Function to read an input hidden return it as string, useful for passwords)
# sendmail 				(function to send smtp mail)
# sqlquery 				(function to query an SQL server)
# writeevent 			(writes events to windows application log)
#######################################################################################################

#--------------------------------------------------------------------------------------------
#Create WSH Objects for backward compatibility to VBScript Functionalities
$oWSHNetwork = New-Object -ComObject wscript.network
$oWSHShell = New-Object -ComObject wscript.shell
$oWSHFSO = New-Object -ComObject Scripting.FileSystemObject
$oADODBCONNECTION = New-Object -comobject ADODB.Connection
$oRECORDSET = New-Object -comobject ADODB.Recordset
#--------------------------------------------------------------------------------------------

write-host "Globalfunctions Ver. $($Globalfunctionversion) with PS Ver. $($host.version.tostring()) successfuly loaded." -ForegroundColor Green


#--------------------------------------------------------------------------------------------
function ConvertToSid() 
{
	$NtAccount = $args[0]
	if (!$NtAccount)
	{
		Write-Host 'Missing Argument! Example: ConvertToSid "Domain\username"'
		break
	}

	$result = (New-Object system.security.principal.NtAccount($NTaccount)).translate([system.security.principal.securityidentifier])
	Write-Host "SID of $NtAccount : $result"
	return $result.value
}
#--------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------
function ConvertToNtAccount() 
{
	
	$sid = $args[0]
	if (!$sid)
	{
		Write-Host 'Missing Argument! Example: ConvertToNtAccount "S-1-5-21-3913922843-3685414615-2778345667-34244"'
		break
	}
	
	$result = (New-Object system.security.principal.securityidentifier($sid)).translate([system.security.principal.ntaccount])
	Write-Host "Account that matches SID: $sid :"
	return $Result.value
}
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function deloldfiles()
{
trap { # this installs an error handler for the function
    Write-Host "Error in Function deloldfiles:" $_.Exception.GetType().FullName + $_.Exception.Message
	continue; # exiting a trap with "continue" says to continue on the next line of the script
  }

 if ($args[0] -eq "-h") {
	Write-Host "usage: deloldfiles <targetfolder> <days to look back> <-f [force]> <-d [directories]>"
	break
}

#count the arguments
if ($args.count -lt 2)
{
Write-Host "Error calling deloldfiles. Too few arguments. use option -h to see help" -foregroundcolor "red"
break
}
 $option = ""
 $TargetFolder = $args[0]
 $days = $args[1]
 $option = $args[2]
 $deletetitems = @()
 
 #some security checks to protect from accidental deletion
 if (!$option -eq '-f')
 {
	if ($TargetFolder.tolower() -eq "c:\windows") {Write-Host "Deleting Files in" $TargetFolder "is not allowed by this function" -ForegroundColor red ;break}
	if ($TargetFolder.tolower() -like "*windows*") {Write-Host "Deleting Files in" $TargetFolder "is not allowed by this function" -ForegroundColor red ;break}
	if ($TargetFolder.tolower() -like "*winnt*") {Write-Host "Deleting Files in" $TargetFolder "is not allowed by this function" -ForegroundColor red ;break}
 }

 
 
  #Warn you the targeted folder, so you can double check
  Write-Host "The Targeted Folder is:" $TargetFolder -foregroundcolor "yellow" -BackgroundColor "Blue"
  #Write-Host `a `a `a `a `a
  #Write-Host "If This Is Not The Intended Target, Press 'Ctrl + C' To Exit" -foregroundcolor "Yellow"
  #Start-sleep -s 15

  $Now = Get-Date

 # Notice the minus sign before $days
  $LastWrite = $Now.AddDays(-$days)
  $Files = Get-ChildItem $TargetFolder -recurse -ea SilentlyContinue 
    
  foreach ($File in $Files)	{
		if ($File.LastWriteTime -le $LastWrite) {
		
			if ($File.PSIsContainer -eq $true) {
				if ($option -eq '-d') {
					Write-Host "Deleting Folder $File" -foregroundcolor "blue" 
					Remove-Item $File.fullname -Recurse | Out-Null -ea SilentlyContinue
					$deleteditems += $File.Name
				}
			}
			else {
				Write-Host "Deleting File $File" -foregroundcolor "blue" 
				Remove-Item $File.fullname -Recurse | Out-Null -ea SilentlyContinue
				$deleteditems += $File.Name
			}
		}
	}
	return $deleteditems
 }
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function getadmin() {
 $ident = [Security.Principal.WindowsIdentity]::GetCurrent()
 
 foreach ( $groupIdent in $ident.Groups ) {
  if ( $groupIdent.IsValidTargetType([Security.Principal.SecurityIdentifier]) ) {
   $groupSid = $groupIdent.Translate([Security.Principal.SecurityIdentifier])
   if ( $groupSid.IsWellKnown("AccountAdministratorSid") -or $groupSid.IsWellKnown("BuiltinAdministratorsSid")){
    return $true
   }
  }
 }
 return $false
}

$Result = getadmin

if ($Result -eq $False) 
  {
    Write-Host "User is not an Administrator."
	#exit
  }
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function dirsize([string]$rootdir) {
$rootdir

trap { # this installs an error handler for the function
    Write-Host "Error in Function dirsize:" $_.Exception.GetType().FullName + $_.Exception.Message
	continue; # exiting a trap with "continue" says to continue on the next line of the script
	}
if (!$rootdir) {
	Write-Host "Error in dirsize function. You must specify a root directory to search in `n" `
	"Usage example: dirsize C:\Windows`n "`
	"Answer: Top10 Foldes`n"`
	"Answer: Top10 Files in current Folder"-ForegroundColor red
	break
	}



	dir $args | where-Object { $_.PSisContainer } | `
	foreach-Object { Write-Progress 'Examining Folder' ($_.FullName); $_ } | `
	foreach-Object { 
		$result = '' | Select-Object Path, FileCount, SizeMB; $result.path = $_.FullName; $temp = Dir $_.FullName -recurse -ea SilentlyContinue |`
		Measure-Object length -sum -ea SilentlyContinue ; $result.filecount = $temp.Count; [double] $result.SizeMB = ('{0:0.0}' -f ($temp.Sum/1MB)); $result 
		} | `
	Sort-Object SizeMB -descending | Select-Object �first 10 | Format-Table -AutoSize
	
	###################################################
	
	
	dir $args |where-Object {!$_.PSisContainer } | `
	foreach-Object {$result = '' |`
	Select-Object Path, SizeMB, LastFileAccess;`
	$result.path = $_.FullName;`
	$result.SizeMB = ('{0:0.0}' -f ($_.Length/1MB));`
	$result.LastFileAccess = $_.LastWriteTime; $result } |`
	Sort-Object SizeMB -descending | Select-Object �first 10 | Format-Table -AutoSize
}

#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function sendmail() {

trap { # this installs an error handler for the function
    Write-Host "Error in Function sendmail:" $_.Exception.GetType().FullName + $_.Exception.Message
	continue; # exiting a trap with "continue" says to continue on the next line of the script
	}

if ($args[0] -eq "-h") {
	Write-Host "usage: sendmail <smtp server> <port> <sender> <recipient1,recipient2> <subject> <body>"
	break
}

#count the arguments
if ($args.count -lt 6)
{
Write-Host "Error calling sendmail. To few arguments. use option -h to see help" -foregroundcolor "red"
break
}

trap { # this installs an error handler for the function
    Write-Host "Error while trying to send mail:" $_.Exception.GetType().FullName + $_.Exception.Message
	continue; # exiting a trap with "continue" says to continue on the next line of the script
  }


$mailhost = $args[0] #define the smtp host
$port = $args[1] # define the smtp host port
$fromaddress = $args[2] # define the sender's email address
$rcpts = $args[3] # define the recipients (multiple separated with comma)
$subject = $args[4] # define the mail subject string
$body = $args[5] # define the mail body 
$attachments = $args[6] #define attachment


#Create mail object and smtp client object
$mail = New-Object system.Net.Mail.MailMessage($fromaddress,$rcpts,$subject,$body)
#add attachments
if ($attachments) {
	foreach ($obj in $attachments) {
		$mail.Attachments.add($obj)
	}

}
#connect the mail server
$mailclient = New-Object system.Net.Mail.SmtpClient($mailhost,$port)

#send the mail
#$MailClient.UseDefaultCredentials = $False 
#$MailClient.Credentials = New-Object System.Net.NetworkCredential(�smtpusername�, �password�)
$mailclient.Send($mail)
}
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function writeevent() {
if ($args[0] -eq "-h") {
	Write-Host "usage: writeevent <event source> <event type:Information,Warning,Error <event id> > <event text>"
	break
}
#count the arguments
if ($args.count -lt 4)
{
write-host "Error calling writeevent. Too few arguments. use option -h to see help" -foregroundcolor "red"
break
}
trap { # this installs an error handler for the function
    write-host "Error writing to eventlog:" $_.Exception.GetType().FullName + $_.Exception.Message
	continue; # exiting a trap with "continue" says to continue on the next line of the script
  }

   $source = $args[0]
   $type = $args[1]
   $eventid = $args[2]
   $msg = $args[3]
   #Create the source, if it does not already exist.
   if(![System.Diagnostics.EventLog]::SourceExists($source))
   {
      [System.Diagnostics.EventLog]::CreateEventSource($source,'Application')
      $logfile = 'Application'
      write-host "Source created and registered in the $logfile Log"
   }
   else 
   {
      $logfile = [System.Diagnostics.EventLog]::LogNameFromSourceName($source,'.')
      #write-host "Source exists and is registered in the $logfile Log"
   }
   #Check if Event Type is correct
   switch ($type) 
   { 
      "Information" {} 
      "Warning" {} 
      "Error" {} 
      default {"Event type is invalid";exit}
   }
   $log = New-Object System.Diagnostics.EventLog 
   $log.set_log($logfile) 
   $log.set_source($source)
   $log.WriteEntry($msg,$type,$eventid)
}
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function sqlquery() {

# get the arguments
param( 
   $Server   = $args[0], 
   $Database = $args[1],  
   $Query    = $args[2],
   $QueryType= $args[3],
   $UserName = $args[4], 
   $Password = $args[5]
   )

if ($args[0] -eq "-h") {
	Write-Host '. d:\admin\scripts\globalfunctions.ps1'
	Write-Host '$dbServer = 'server1'# Database Server\Instance'
	Write-Host '$Database = "dbMaster" 	# Datenbank'
	Write-Host 'sqlquery $dbServer $Database "select * from [dbMaster].[dbo].[MAdata] WHERE (id = '126')" "-a"' 
	Write-Host 'sqlquery $dbServer $Database "UPDATE [dbMaster].[dbo].[MAdata] SET [domain] = 'c1' WHERE (id = '126')" "-a"'
	Write-Host 'sqlquery $dbServer $Database "INSERT INTO [dbMaster].[dbo].[MAdata] (id,setid_dept)Values(999,'test01')" "-a"'
	Write-Host 'sqlquery $dbServer $Database "Delete from [dbMaster].[dbo].[MAdata] WHERE (id = '999')" "-a"'
	break
}	

 
 #If TSQL inputfile specified, use this as query string
 if ($Query -like "*.sql") {
 	$Query = Get-Content $Query
	}

 
# get credentials if supplied, otherwise use integrated sspi authentication
if( ($UserName -gt $null) -and ($Password -gt $null)) {
    $login = "User Id = $UserName; Password = $Password"
} else {
    $login = "Integrated Security = True"
}

# Setup SQL Connection
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $Server; Database = $database; $login"

# Setup SQL Command
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection

$SqlCmd = New-Object System.Data.SqlClient.SqlCommand $Query, $SqlConnection
trap { # this installs an error handler for the function
    Write-Host "Error in function SQLQUERY:" $_.Exception.GetType().FullName + $_.Exception.Message
	continue; # exiting a trap with "continue" says to continue on the next line of the script
  }

if ($QueryType -eq "-a") {
		
		#perform a query that returns a table full of data
  		$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  		$SqlAdapter.SelectCommand = $SqlCmd
 
  		$DataSet = New-Object System.Data.DataSet
		$SqlAdapter.Fill($DataSet) | Out-Null
  		if ($Query -match 'SELECT')
		{
  			return $DataSet.Tables[0]
		}
		}
		
		
if ($QueryType -eq "-s"){
	
		if (-not ($SqlConnection.State -like "Open")) { $SqlConnection.Open() }
  		$SqlCmd = New-Object System.Data.SqlClient.SqlCommand $Query, $SqlConnection

		#perform a query that returns single values
  		$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
  		$SqlAdapter.SelectCommand = $SqlCmd
 
  		$DataSet = New-Object System.Data.DataSet
  		
		$SqlAdapter.Fill($DataSet) | Out-Null
		$results = $DataSet.Tables[0]
		foreach ($result in $results) {
			"AlertName: " + $result.Name
			"Alert Description: " + $result.Description 
			} 
			
		}
#close the sql connection
$SqlConnection.Close()		
}
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function  psexec(){

	trap { # this installs an error handler for the function
   		 Write-Host "Error in function psexec:" $_.Exception.GetType().FullName + $_.Exception.Message
		continue; # exiting a trap with "continue" says to continue on the next line of the script
 	 }


     $application = $args[0]
     $arguments = $args[1]
     $loopcmd = $args[3]
     $process = [Diagnostics.Process]::Start($application,$arguments)

	#get args and loop each 
     foreach ($arg in $args) {
           if ($arg -eq "waitforexit") {
                Write-Host "Waiting process:" $application "  to exit"
                do {sleep(1)} while (!$process.HasExited)
           }
     }
}
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function  checkprocs(){

	 trap { # this installs an error handler for the function
   		 Write-Host "Error in function checkprocs:" $_.Exception.GetType().FullName + $_.Exception.Message
		continue; # exiting a trap with "continue" says to continue on the next line of the script
 	 }
	 
	 #count the arguments
	 if ($args.count -lt 1){
	 Write-Host "Error calling checkprocs. Too few arguments. use option -h to see help" -foregroundcolor "red"
	 break
	 }
	 
	 #Display Help
	 if ($args[0] -eq "-h") {
	 Write-Host "usage: checkprocs <process1> <process2> <process3> ...."
	 break
	 }


    $procsfailed = @()
	$procsok = @()

	#get args and loop each 
     foreach ($arg in $args) {
	 	   
           $arrprocs = Get-Process | where { $_.Name -eq $arg } 
		   foreach ($proc in $arrprocs) {
		   		if ($proc.Name -ne $arg) {
					$procsfailed += $arg
				}
				else {
					$procsok += $arg
				}
		   }
     }
	 Write-Host "Processes failed:" $procsfailed
	 Write-Host "Processes ok:" $procsok
	 if ($procsfailed -ne "") {
	    Write-Host "oops! Some processes not running!"
	 	return $procsfailed
	 }
	 else {
	 	Write-Host "Everything looks ok!"
	 	return $TRUE
	 }
}
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function  checksvc(){

	 trap { # this installs an error handler for the function
   		 Write-Host "Error in function checksvc:" $_.Exception.GetType().FullName + $_.Exception.Message
		continue; # exiting a trap with "continue" says to continue on the next line of the script
 	 }
	 
	 #count the arguments
	 if ($args.count -lt 1){
	 Write-Host "Error calling checksvc. Too few arguments. use option -h to see help" -foregroundcolor "red"
	 break
	 }
	 
	 #Display Help
	 if ($args[0] -eq "-h") {
	 Write-Host "checksvc function written by M.Rueefli `n
	 usage: checksvc <service1> <service2> <service3> ...."
	 break
	 }


    $svcfailed = @()
	$svcsok = @()

	#get args and loop each 
     foreach ($arg in $args) {
	   	   $arrsvc = Get-Service | where { $_.Name -eq $arg } 
		   foreach ($svc in $arrsvc) {
		   		if ($svc.Status -ne "Running") {
					$svcfailed += $arg
					if ($arg -eq "autofix") {
						Start-Service $svc
					}
				}
				else {
					$svcok += $arg
				}
		    }
	    
     }
	 Write-Host "Services failed:" $svcfailed
	 Write-Host "Services ok:" $svcok
	 if ($svcfailed -ne "") {
	    Write-Host "oops! Some Services not running!"
		return $svcfailed
	 }
	 else {
	 	Write-Host "Everything looks ok!"
	 	return $TRUE
	 }
}
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function dirwatcher([string]$path){
    
	trap { # this installs an error handler for the function
        Write-Host "Error in Function dirwatcher:" $_.Exception.GetType().FullName + $_.Exception.Message
	    continue; # exiting a trap with "continue" says to continue on the next line of the script
    }
	$fsw = New-Object System.IO.FileSystemWatcher
	$fsw.Path = $path
	$result = $fsw.WaitForChanged("created")
	$result

}

#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function convertTObase64() {
    trap { # this installs an error handler for the function
        Write-Host "Error in Function convertTObase64:" $_.Exception.GetType().FullName + $_.Exception.Message
	    continue; # exiting a trap with "continue" says to continue on the next line of the script
    }
    #count the arguments
	 if ($args.count -lt 1){
	 Write-Host "Too few arguments. Usage: convertTObase64 <string to convert>" -foregroundcolor red
	 break
	 }
    $str = $args[0]
    $encstr = [System.Convert]::ToBase64String([System.Text.Encoding]::UNICODE.GetBytes($str))
    return $encstr
}
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function convertFROMbase64() {
    trap { # this installs an error handler for the function
        Write-Host "Error in Function convertFROMbase64:" $_.Exception.GetType().FullName + $_.Exception.Message
	    continue; # exiting a trap with "continue" says to continue on the next line of the script
    }
    #count the arguments
	 if ($args.count -lt 1){
	 Write-Host "Too few arguments. Usage: convertFROMbase64 <string to convert>" -foregroundcolor red
	 break
	 }
    $str = $args[0]
    $clrstr = [System.Text.Encoding]::UNICODE.GetString([System.Convert]::FromBase64String($str))

    return $clrstr
}
#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
function Read-HostMasked([string]$prompt="Password") {
  $password = Read-Host -AsSecureString $prompt;  
  $BSTR = [System.Runtime.InteropServices.marshal]::SecureStringToBSTR($password);
  $password = [System.Runtime.InteropServices.marshal]::PtrToStringAuto($BSTR);
  [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($BSTR);
  return $password;
}
#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
function makegroup ()
{
  $usrfile = "C:\Cygwin\etc\passwd"
  $groupfile = "C:\Cygwin\etc\group"
  
  Write-Host "--------------------------------------------------------------------------"
  Write-Host "makegroup function for Cygwin configuration"
  Write-Host "--------------------------------------------------------------------------"

  $groupname = Read-Host "Please enter the groupname you like to add to /etc/group file"
  if (!$groupname)
  {
  	Write-Host "No Groupname entered. Exiting!"
	break
  }

  $groupsid  = ConvertToSid "$groupname"
  $groups    = Get-Content  "$groupfile"
  
  $samaccount = "$groupname"
  if ($samaccount -match "\\")
  {
  	$samaccount = $groupname.Split("\")
  	$samaccount = $samaccount[1]
  }
  
    
  $gid  = $groupsid.split("-")
  $gid = $gid[-1]

  if ($groups -match $samaccount )
  {
  	Write-Host "Group $groupname already exists in /etc/group!" -ForegroundColor red
	break
  }
  
   Add-Content $groupfile ($samaccount + ':' + $groupsid + ':' + $gid + ':')
   Write-Host "Group $groupname added to $groupfile" -ForegroundColor Green
     
 }
#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
function makepasswd ()
{
  $usrfile = "C:\Cygwin\etc\passwd"
  $groupfile = "C:\Cygwin\etc\group"
  
  Write-Host "--------------------------------------------------------------------------"
  Write-Host "makepasswd function for Cygwin configuration"
  Write-Host "--------------------------------------------------------------------------"

  $username = Read-Host "Please enter the username you like to add to /etc/passwd"
  if (!$UserName)
  {
  	Write-Host "No Username entered. Exiting!"
	break
  }
  $homedir = Read-Host "Please enter the users homedir (eg. /ftproot or similar)"
  if (!$homedir)
  {
  	Write-Host "No homedir entered. Exiting!"
	break
  }
  $usersid  = ConvertToSid $UserName
  $passwdfile = Get-Content "$usrfile"
  
  $samaccount = $UserName
  if ($samaccount -match "\\")
  {
  	$samaccount = $UserName.Split("\")
  	$samaccount = $samaccount[1]
  }
 
    
  $uid  = $usersid.split("-")
  $uid = $uid[-1]

  if ($passwdfile -match $samaccount )
  {
  	Write-Host "User $samaccount already exists in /etc/passwd!" -ForegroundColor red
	break
  }
  
	$title = "Remote Shares?"
	$message = "Do you want to use a remote share for this users base dir?" 
	$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Searches for GUID of GS-XX-XXXX-SSHUSer"
	$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "Ignores GUID of SSHUser Group (use this option for local sftp accounts)"
	$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
	$result = $host.ui.PromptForChoice($title, $message, $options, 1) 
	switch ($result)
    {
        0 {$sshgroup = Get-Content "$groupfile" | ? { $_ -match 'sshuser' } ; `
			if (!$sshgroup)
			{
				Write-Host "Error, GS-X2-XXXX-SSHUser AD Group not found in /etc/group! Use makegroup first to add the group." -ForegroundColor red
				break
			}
			$sshgroup = $sshgroup.split(":") ; `
			$sshgroupguid = $sshgroup[2]; `
			Add-Content $usrfile ($samaccount + ':unused_by_nt/2000/xp:' + $uid + ':' + $sshgroupguid + ':' + $samaccount + ',U-' + $username + ',' + $usersid + ':' + $homedir + ':/bin/bash') ; `
			Write-Host "Added $username to $usrfile" -ForegroundColor Green}
       
		1 {$sshgroup = Get-Content "$groupfile" | ? { $_ -match 'None' } ; `
			$sshgroup = $sshgroup.split(":") ; `
			$sshgroupguid = $sshgroup[2]; `
			$strComputer = "."
			$computer = [ADSI]("WinNT://" + $strComputer + ",computer")
			$computer.name
			$Users = $computer.psbase.children |where{$_.psbase.schemaclassname -eq "User"}
			$userexists = $false
			foreach ($member in $Users.psbase.syncroot)
			{
				if ($member.name -eq $samaccount) { $userexists = $true }
			}
			if ($userexists -eq $false)
			{
				Write-Host "Error: Local Windows User does not exist! Create it first!" -ForegroundColor Red
				break
			}
			Add-Content $usrfile ($samaccount + ':unused_by_nt/2000/xp:' + $uid + ':' + $sshgroupguid + ':' + $samaccount +',U-' + $oWSHNetwork.ComputerName + '\' + $samaccount + ',' + $usersid + ':' + $homedir + ':/bin/bash') ;`

			Write-Host "Added $username to $usrfile" -ForegroundColor Green}
    }
 }
#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
function find_replace($file,$findstr,$replacestr)
{
if ($args[0] -eq "-h") {
	Write-Host "usage: find_replace <Filename>,<Find-String>,<Replace-Sring>,[-o <NewOutputFile>],[-e <Encoding Ascii,BigEndianUnicode,Byte,String,Unicode,Unknown,UTF7,UTF8>]"
	break
	}
	$i= 0
	$argcount = ($args).count
	while ($i -lt $argcount) {
		if ($args[$i] -eq "-o"){
			$newfile = $args[$i+1]
			}
		if ($args[$i] -eq "-e"){
			$encoding = $args[$i+1]
			}
		$i++
		}
	if (($newfile) -and ($encoding)){
		$input =  Get-Content $file -Encoding $encoding
		$output = $input -replace($findstr,$replacestr)
		Set-Content $newfile $output -Encoding $encoding
		}
	elseif ($newfile){
		$input =  Get-Content $file 
		$output = $input -replace($findstr,$replacestr)
		Set-Content $newfile $output 
		}
	elseif ($encoding){
		$input =  Get-Content $file -Encoding $encoding
		$output = $input -replace($findstr,$replacestr)
		Set-Content $file $output -Encoding $encoding
		}
	elseif ($argcount -eq 0) {
		$input =  Get-Content $file
		$output = $input -replace($findstr,$replacestr)
		Set-Content $file $output
		}		
}	
#---------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function Import-509Certificate 
{     
   param([String]$certPath,[String]$certRootStore,[String]$certStore)     
   
   if ($args[0] -eq "-h") 
   {
		Write-Host "usage: Import-509Certificate <Filename>,<certstore>,<cert root> `n `
		Valid certstores: LocalMachine,CurrentUser `n `
		Valid cert root: My,AuthRoot,TrustedPublisher"
		break
   }
   
   $pfx = new-object System.Security.Cryptography.X509Certificates.X509Certificate2     
   $pfx.import($certPath)     
   $store = new-object System.Security.Cryptography.X509Certificates.X509Store($certStore,$certRootStore)    
   $store.open("MaxAllowed")     
   $store.add($pfx)     
   $store.close()     
}    
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
function Import-PfxCertificate 
{     
   param([String]$certPath,[String]$certRootStore,[String]$certStore,$pfxPass = $null)     

	if ($args[0] -eq "-h") 
   {
		Write-Host "usage: Import-509Certificate <Filename>,<certstore>,<cert root> `n `
		Valid certstores: LocalMachine,CurrentUser `n `
		Valid cert root: My,AuthRoot,TrustedPublisher"
		break
   }
   
   $pfx = new-object System.Security.Cryptography.X509Certificates.X509Certificate2     
   if ($pfxPass -eq $null) {$pfxPass = read-host "Enter the pfx password" -assecurestring}     
   $pfx.import($certPath,$pfxPass,"Exportable,PersistKeySet")     
   $store = new-object System.Security.Cryptography.X509Certificates.X509Store($certStore,$certRootStore)     
   $store.open("MaxAllowed")     
   $store.add($pfx)     
   $store.close()     
}    
#--------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------
Function exportPFX()
{
	
	#Get the Arguments
	$exportpath = $args[0]
	$certstore = $args[1]
	$issuer_filter = $args[2]
	
	#Check the Args
	If ($args.count -lt 2)
	{
		Write-host "Too less arguments! Usage: exportPFX <exportpath> <certstore> [<filter> optional>" -ForegroundColor red
		write-host "Example: Powershell.exe ExportCert.ps1 H:\Certs CurrentUser DC=LOC" -ForegroundColor blue
		exit
	}
	
	#Error Handler
	Trap [Exception]{continue}
	
	#Check Exportpath, if not there create it
	If ((Test-Path -Path $exportpath) -ne $True)
	{
		New-Item -Path $exportpath -ItemType Directory 
	}
	
	#Get certificates in store
	If ($issuer_filter)
	{
		$HKCUCerts = (dir "cert:\$certstore\My" | ? { $_.Issuer -notmatch $issuer_filter})
	}
	Else
	{
		$HKCUCerts = (dir "cert:\$certstore\My")
	}
	
	#process each certificate
	Foreach ($cert in $HKCUCerts)
	{
		$friendlyname = $cert.FriendlyName
		$type = [System.Security.Cryptography.X509Certificates.X509ContentType]::pfx
		$username = $env:USERNAME
		$sid  = (New-Object system.security.principal.NtAccount($username)).translate([system.security.principal.securityidentifier])
		$pass = "$friendlyname-$sid"
		$pass_secure = ConvertTo-SecureString -AsPlainText $pass -Force
		$bytes = $cert.export($type, $pass)
		[System.IO.File]::WriteAllBytes("$exportpath\$friendlyname.pfx", $bytes)
	}
}
#--------------------------------------------------------------------------------------------
