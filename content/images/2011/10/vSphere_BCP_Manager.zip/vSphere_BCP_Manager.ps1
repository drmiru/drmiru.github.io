﻿######################################################################################################
# Scrite: vSphere BCP Manager 
# Author: Michael Rueefli
# Copyrights: 2011 / INSERTO AG
# Version: 0.98
# Date: 01.02.2011
# 
# Description:	  The Script is intended to do SRM stuff while not requiring to having 
#				  SRM implementation in place. The script currently only works with vSphere 4 and 5 and 
#				  NetApp Storage attached via iSCSI or NFS. The script basically does the following fully
#				  automated.
#				  - Breaking up Snapmirror relationships
#				  - Mapping the mirror LUNs / NFS Volumes to the BCP vSphere hosts and performing storage rescan
#				  - Registering VMs on the mirror datastores
#				  - Changing vSwitch port group and connecting the VM NIC
#				  - Starting the VMs
#				  - change the IP config of guest
#				  - Final reboot of the guests
#				  --> most of the options can be enabled/disabled in the mainconfig.cfg file
#
#
# Prerequisites:
#				- Powershell 2.0 Installed
#				- vSPhere PowerCLI 5 and NetApp DataONTAP Powershell toolkit 1.5 installed
#				- SSL Port open to vCenter and ESX Hosts
#				- Netapp API Port (80 / 443) open to NetApp Devices
#				- Logins for vCenter / ESX Host / Netapp Filer / Guest VMs --> with apropriate permissions
#				- Powershell installed inside the guest for auto changing the IP configuration (execution policy set to remotesigned)
#
#
# Disclaimer:
#
# 
# Changes:		03/08/2011 - v.096 / set $esxhost to "" in vm register loop to avoid caching of variable
#				10(10/2011 - v.097 / added snapmirror update feature before breaking up the mirror
#				11/10/2011 - v.098 / added support for NFS Datastores
######################################################################################################

#Check script args
If ($args.count -lt 1)
{
	write-host "No Arguments speficied. Submit the main config file as first argument. Aborting now." -ForegroundColor Yellow
	break
}

function gettimestamp()
{
    $ts = (get-date -f "d-MM-yyyy-HH:mm:ss:fff")
    return $ts
}

#Reading Config file submitted with argument
$confparams = Get-Content $args[0]
Foreach ($parameter in $confparams)
{
	If (($parameter -notmatch '^\#') -and ($parameter -match '^\S'))
	{
		$parameter = $parameter -replace '\s',''
		$parameter = $parameter.Split(";")
		switch ($parameter[0])
		{
			'VM_CONFIG_FILE' 					{ $VMImportFile = $parameter[1] }
			'STORAGE_CONFIG_FILE'				{ $StorageConfFile = $parameter[1] }
			'NETAPP_API_PORT'					{ $NAPort = $parameter[1] }
			'VCENTER_HOSTNAME'					{ $VCHost = $parameter[1] }
			'NAS_USERNAME'						{ $nasuser = $parameter[1] }
			'NAS_PW'							{ $nasuserpw = $parameter[1] }
			'GUEST_ADMIN_USER'					{ $guestuser = $parameter[1] }
			'GUEST_ADMIN_PW'					{ $guestuserpw = $parameter[1] }
			'LOGFILE_PATH'						{ $logfilepath = $parameter[1] }
		}
	}
}

$timestamp = gettimestamp
$timestamp
$logfiletimestamp = (get-date -uformat %d%m%Y-%H%M%S)
$logfile = "$logfilepath\BCP-Manager-$logfiletimestamp.log"
#Activate Error Handler
 Trap 
 {
    $timestamp = gettimestamp
	$timestamp + '-' + $username +': Fatal Error at ' + $_.InvocationInfo.PositionMessage + ':' + $_.Exception.Message | Out-File $logfile -Append
    continue
 }




"$timestamp : ---- vSphere BCP Manager (c)2011 INSERTO AG started -----" | Out-File $logfile
"$timestamp : Registering Powershell Snapins" | Out-File $logfile -Append

#Register VMware VIM Automation SnapIn 
Add-PSSnapin VMware.VimAutomation.Core -ErrorAction SilentlyContinue
#Import ONTAP Powershell modules
Import-Module DataONTAP -ErrorAction SilentlyContinue

#--------------------------------------------------------------------------------------------
function convertFROMbase64() {
    trap { # this installs an error handler for the function
        #Write-Host "Error in Function convertFROMbase64:" $_.Exception.GetType().FullName + $_.Exception.Message
	    continue; # exiting a trap with "continue" says to continue on the next line of the script
    }
    #count the arguments
	 if ($args.count -lt 1){
	 Write-Host "Too few arguments. Usage: convertFROMbase64 <string to convert>" -foregroundcolor red
	 break
	 }
    $str = $args[0]
    $clrstr = [System.Text.Encoding]::UNICODE.GetString([System.Convert]::FromBase64String($str))

    return $clrstr
}
#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
Function trim($file,$mode)
{
	$input = Get-Content $file
	$output = $input | where {$_ -notmatch "^$" }
	If ($mode -eq 'includeblanks')
	{
		$output = $output -replace(' ','')
	}
	Set-Content $file $output
}
#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
Function BCP_SHOW_CONFIG()
{
	Write-Host "***************************************"
	Write-Host "Current Storage config                 "
	Write-Host "***************************************"
	gc $StorageConfFile
	Write-Host " "
	Write-Host " "
	Write-Host " "
	Write-Host "***************************************"
	Write-Host "Current VM config                      "
	Write-Host "***************************************"
	gc $VMImportFile
	Write-Host " "
	Write-Host " "

	read-host "Press any key to return to menue..."
	MAIN

}
#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
Function BCP_EDIT_STORAGE_CONFIG()
{
	CLS
	Write-Host "Editing storage configuration file"
	Invoke-Expression ('notepad.exe ' + $StorageConfFile)

	read-host "Press any key to return to menue..."
	MAIN
}
#---------------------------------------------------------------------------------------


Function BCP_EDIT_VM_CONFIG()
{
	CLS
	Write-Host "Editing storage configuration file"
	Invoke-Expression ('notepad.exe ' + $VMImportFile)

	read-host "Press any key to return to menue..."
	MAIN
}
#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
Function BCP_SWITCH()
{
	
	$timestamp = gettimestamp
	"$timestamp : BCP Switch startet" | Out-File $logfile -Append
	#Connecting to vCenter server 
	If (!$vCenterCred) 
	{
		$timestamp = gettimestamp
		"$timestamp : Asking for vCenter Credentials" | Out-File $logfile -Append
		$vCenterCred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for vCenter $VCHost", "", "") 
	}
	$timestamp = gettimestamp
	"$timestamp : Connecting to vCenter $VCHost" | Out-File $logfile -Append
	$vCenterConnection = Connect-VIServer -Server $VCHost -Credential $vCenterCred -ErrorVariable E_VCENTER_CONNECTION
	While (!$vCenterConnection)
	{
		write-host "Error connecting to vCenter, check username and password!"-ForegroundColor Yellow
		$timestamp = gettimestamp
		"$timestamp : ERROR: Could not connect to vCenter $VCHost. Check username and password" | Out-File $logfile -Append
		$vCenterCred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for vCenter", "", "")
		$vCenterConnection = Connect-VIServer -Server $VCHost -Credential $vCenterCred -ErrorVariable E_VCENTER_CONNECTION
	}

	#Proceed with BCP Storage
	trim $StorageConfFile includeblanks
	$storageconf = Import-CSV $StorageConfFile
	foreach ($item in $storageconf) 
	{     
		
		If ($item -notmatch '#')
		{
			#Read out the paramaters from CSV File
			$bcpcluster = $item.bcp_cluster 
			$bcpdatastore = $item.orig_datastore 
			$bcp_nas_filer = $item.bcp_nasfiler 
			$bcp_nas_lun = $item.bcp_naslun 
			$bcp_nas_lun_id = $item.lun_map_id 
			$bcp_igroup_name = $item.iscsi_igroupname 
			$bcp_vol = $bcp_nas_lun.Split('/')[2]
			$clusterhosts = Get-Cluster $bcpcluster | Get-VMHost
			#Collecting Credential Cache for ESX Hosts in Cluster
			If (!$arr_hostcred)
			{
				$arr_hostcred = @()
				$timestamp = gettimestamp
				"$timestamp : Collecting host members for cluster: $bcpcluster" | Out-File $logfile -Append
				$hostsincluster = Get-Cluster -Name $bcpcluster | get-VMHost
				Foreach ($object in $hostsincluster)
				{
					$HostCred = "" | Select-Object Credentials,HostName
					$HostCred.HostName = $object.Name
					$hname = $object.Name
					$timestamp = gettimestamp
					"$timestamp : Getting Credentials for Host: $hname" | Out-File $logfile -Append
					$HostCred.Credentials = $Host.UI.PromptForCredential("Please enter credentials", "Enter credentials for ESX Host: $object.Name", "", "")
					$arr_hostcred += $HostCred
				}
			}

			#Connecting to the netapp host
			If (!$NACred)
			{
				If ($nasuser -and $nasuserpw)
				{
					$nasuserpw = ConvertFromBase64 $nasuserpw
					$nasuserpw_secure = ConvertTo-SecureString $nasuserpw -asplaintext -force
					$NACred = New-Object -typename System.Management.Automation.PSCredential -argumentlist $nasuser,$nasuserpw_secure
					$timestamp = gettimestamp
					"$timestamp : Connecting to BCP Filer $bcp_nas_filer with predefined credentials" | Out-File $logfile -Append
					write-host "Connecting to BCP Filer $bcp_nas_filer" -ForegroundColor Green
					Switch ($NAPort)
					{
						"80" 
							{
								$NASConnection = Connect-NaController $bcp_nas_filer -HTTP -Credential $NACred
								While (!$NASConnection)
								{
									write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
									$timestamp = gettimestamp
									"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
									$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
									$NASConnection = Connect-NaController $bcp_nas_filer -HTTP -Credential $NACred
								}
							}
						"443" 
							{
								$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred
								While (!$NASConnection)
								{
									write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
									$timestamp = gettimestamp
									"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
									$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
									$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred
								}
							}
						"135" 
							{
								$NASConnection = Connect-NaController $bcp_nas_filer -RPC -Credential $NACred
								While (!$NASConnection)
								{
									write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
									$timestamp = gettimestamp
									"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
									$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
									$NASConnection = Connect-NaController $bcp_nas_filer -RPC -Credential $NACred
								}
							}
						Default 
							{
								$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
								While (!$NASConnection)
								{
									write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
									$timestamp = gettimestamp
									"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
									$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
									$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
								}
							}
					}
					

				}
			}
			If (!$NACred) 
			{
				$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter credentials for NetApp Filer: $bcp_nas_filer", "", "") 
				write-host "Connecting to BCP Filer $bcp_nas_filer" -ForegroundColor Green
				$timestamp = gettimestamp
				"$timestamp : Connecting to BCP Filer $bcp_nas_filer" | Out-File $logfile -Append
				Switch ($NAPort)
					{
						"80" 
							{
								$NASConnection = Connect-NaController $bcp_nas_filer -HTTP -Credential $NACred 
								While (!$NASConnection)
								{
									write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
									$timestamp = gettimestamp
									"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
									$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
									$NASConnection = Connect-NaController $bcp_nas_filer -HTTP -Credential $NACred 
								}
							}
						"443" 
							{
								$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
								While (!$NASConnection)
								{
									write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
									$timestamp = gettimestamp
									"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
									$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
									$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
								}
							}
						"135" 
							{
								$NASConnection = Connect-NaController $bcp_nas_filer -RPC -Credential $NACred 
								While (!$NASConnection)
								{
									write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
									$timestamp = gettimestamp
									"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
									$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
									$NASConnection = Connect-NaController $bcp_nas_filer -RPC -Credential $NACred
								}
							}
						Default 
							{
								$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
								While (!$NASConnection)
								{
									write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
									$timestamp = gettimestamp
									"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
									$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
									$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
								}
							}
					}
			}
	
			#Check snapmirror state and perform update
			$timestamp = gettimestamp
			"$timestamp : Checking volume snap mirror state of volume: $bcp_vol" | Out-File $logfile -Append
            $volstate = (Get-NaSnapmirror | where { $_.DestinationLocation -match $bcp_nas_filer+':'+$bcp_vol}).State
			If ($volstate -ne 'broken-off')
			{
				$mirrorstate = (Get-NaSnapmirror | where { $_.DestinationLocation -match $bcp_nas_filer+':'+$bcp_vol}).Status
				$snstate = "dummy"
	            switch ($mirrorstate)
	            {
	             "idle" 
	                    {

	                        $timestamp = gettimestamp
							"$timestamp : State is Idle, performing snapmirror update for volume: $bcp_vol" | Out-File $logfile -Append
							write-host "Updating snapmirror to destination volume: $bcp_nas_filer:$bcp_vol" -ForegroundColor Green
	                         Get-NaSnapmirror | where { $_.DestinationLocation -match $bcp_nas_filer+':'+$bcp_vol} | invoke-NaSnapmirrorUpdate
	                         while ($snstate -ne 'idle')
	                         {
	                         	$timestamp = gettimestamp
								"$timestamp : Waiting up to 30 seconds for snapmirror to finish for volume: $bcp_vol" | Out-File $logfile -Append
								write-host "Waiting up to 30 seconds for snapmirror to finish" -ForegroundColor Green
	                            start-sleep -Seconds 30
	                            $snstate = (Get-NaSnapmirror | where { $_.DestinationLocation -match $bcp_nas_filer+':'+$bcp_vol}).Status
	                         }
	                         	$timestamp = gettimestamp
								"$timestamp : Breaking up snapmirror to destination volume: $bcp_nas_filer:$bcp_vol" | Out-File $logfile -Append
								write-host "Breaking up snapmirror to destination volume: $bcp_nas_filer:$bcp_vol" -ForegroundColor Green
	                            Invoke-NaSnapmirrorBreak -Destination $bcp_vol -Confirm:$false | Out-Null
	                         }
	             "transferring"

	                    {
	                        while ($snstate -ne 'idle')
	                        {
	                        	$timestamp = gettimestamp
								"$timestamp : There is already an ongoing update transfer for volume: $bcp_vol . Waiting up to 30 seconds for snapmirror to finish" | Out-File $logfile -Appen
								write-host "There is already an ongoing update transfer. Waiting up to 30 seconds for snapmirror to finish" -ForegroundColor Green
	                        	start-sleep -Seconds 30
	                        	$snstate = (Get-NaSnapmirror | where { $_.DestinationLocation -match $bcp_nas_filer+':'+$bcp_vol}).Status
	                        }
							"$timestamp : Breaking up snapmirror to destination volume: $bcp_nas_filer:$bcp_vol" | Out-File $logfile -Append
							write-host "Breaking up snapmirror to destination volume: $bcp_nas_filer:$bcp_vol" -ForegroundColor Green
							Invoke-NaSnapmirrorBreak -Destination $bcp_vol -Confirm:$false | Out-Null
	                    }
	            }
			}
			Else
			{
				$timestamp = gettimestamp
				"$timestamp : Volume $bcp_vol is already broken up.. nothing to do for now" | Out-File $logfile -Append
				write-host "Volume $bcp_vol is already broken up.. nothing to do for now..." -ForegroundColor Green
			}


			Foreach ($item in $clusterhosts)
			{
				

				#Enable VMFS Volume resignaturing
				$timestamp = gettimestamp
				"$timestamp : Enabling LVM resignaturing on hosts..." | Out-File $logfile -Append
				write-host "Enabling LVM resignaturing on hosts..." -ForegroundColor Green
				[long]$Value = 1
				$option = New-Object VMware.Vim.Optionvalue -Property @{
				  Key = "LVM.EnableResignature"
				  Value = $Value
				}
				$esx = Get-View (Get-VMHost ($item.Name)).ID
				$optmgr = Get-View $esx.configManager.advancedOption
				$optarray = $option
				$optmgr.UpdateOptions($optarray)
				
				If ($bcpdatastore -match 'ISCSI')
				{
					#Mapping LUNs to igroup
					$timestamp = gettimestamp
					"$timestamp : ISCSI Datastore: Mapping $bcp_nas_lun to iGROUP $bcp_igroup_name with LUNid $bcp_nas_lun_id" | Out-File $logfile -Append
					write-host "ISCSI Datastore: Mapping $bcp_nas_lun to iGROUP $bcp_igroup_name with LUNid $bcp_nas_lun_id" -ForegroundColor Green
					Add-NaLunMap -Path $bcp_nas_lun -InitiatorGroup $bcp_igroup_name -ID $bcp_nas_lun_id -ErrorAction SilentlyContinue -ErrorVariable E_MAP_LUN | Out-Null
					#Rescanning All ESX host's storage adapter
					$timestamp = gettimestamp
					"$timestamp : Rescanning storage adapters on $item" | Out-File $logfile -Append
					write-host "Rescanning storage adapters on $item" -ForegroundColor Green
					Get-VMHostStorage -VMHost $item.Name -RescanAllHBA:$True -RescanVMFS:$True | Out-Null
					write-host "Sleeping 5 seconds..." -ForegroundColor Green
				}
				Elseif ($bcpdatastore -match 'NFS')
				{
					$timestamp = gettimestamp
					"$timestamp : NFS Datastore: Mapping $bcp_nas_lun to $bcp_nas_lun_id" | Out-File $logfile -Append
					write-host "NFS Datastore: Mapping $bcp_nas_lun to $bcp_nas_lun_id" -ForegroundColor Green
					New-Datastore -Nfs -VMHost $item.Name -Name "snap-$bcpdatastore" -Path $bcp_nas_lun -NfsHost $bcp_nas_lun_id
					#Rescanning All ESX host's VMFS Volumes
					$timestamp = gettimestamp
					"$timestamp : Rescanning VMFS Datastores on $item" | Out-File $logfile -Append
					write-host "Rescanning VMFS Datastores on $item" -ForegroundColor Green
					Get-VMHostStorage -VMHost $item.Name -RescanVMFS:$True | Out-Null
					write-host "Sleeping 5 seconds..." -ForegroundColor Green
				}
				
			}
		}
	}

	#Read VMs to proceed and go
	$timestamp = gettimestamp
	"$timestamp : Reading VM Config file to get VMs to proceed with" | Out-File $logfile -Append
	trim $VMImportFile includeblanks
	$vmlist = Import-CSV $VMImportFile
	foreach ($item in $vmlist) 
	{     
		
		If ($item -notmatch '#')
		{
			#Read out the paramaters from CSV File
			$datacenter = $item.datacenter 
			$bcpcluster = $item.bcp_cluster 
			$bcpdatastore = $item.orig_datastore 
			$vmname = $item.vmname 
			$portgroup = $item.portgroupname
			$ipaddr = $item.ipaddress 
			$subnet = $item.subnet 
			$gateway = $item.gateway 
			$pdns = $item.pdns

			#Register VM
			$firsthost = (get-Cluster $bcpcluster | Get-VMHost)[0]
			$hostname = $firsthost.name
			$newdatastore = (Get-datacenter -Name $datacenter |  Get-Datastore | ? { $_.name -match "snap-.*$bcpdatastore"})
			$newdatastore = $newdatastore.Name
			$ResourcePool = Get-Cluster -Name $bcpcluster | Get-ResourcePool | Get-View 
			$newvmname = $vmname+'_BCP'
			$vmFolder = Get-View (Get-Datacenter -Name $datacenter | Get-Folder -Name "vm").id 
			$timestamp = gettimestamp
			"$timestamp : Registering $newvmname on datastore $newdatastore" | Out-File $logfile -Append
			write-host "Registering $newvmname on datastore $newdatastore" -ForegroundColor Green
			$vmFolder.RegisterVM_Task("[$newdatastore]/$vmname/$vmname.vmx", $newvmname, $false, $ResourcePool.MoRef, $null)			
			
							
			#Connect back to vCenter  
			Disconnect-VIServer * -Confirm:$false
			$vCenterConnection = Connect-VIServer -Server $VCHost -Credential $vCenterCred -ErrorVariable E_VCENTER_CONNECTION
			Start-Sleep -Seconds 2
				
					
			#Get the ESX Host the VM is registered on
			$timestamp = gettimestamp
			"$timestamp : Get the ESX Host the VM: $newvmname is registered on" | Out-File $logfile -Append
			$esxhost = ""
			While (!$esxhost)
			{
				$vm = Get-VM | ? { $_.name -match "$newvmname"}
				$esxhost = $vm.VMHost.Name
				$timestamp = gettimestamp
				"$timestamp : VM: $newvmname is registered on Host: $esxhost" | Out-File $logfile -Append
				write-host "VM is registered on Host: $esxhost" -ForegroundColor Green
			}
					
			#Connect to ESX Host directly because of a bug in vSphere PowerCLI where you can't start a VM without a valid Port Group
			Disconnect-VIServer * -Confirm:$false
			#Ask for the crecentials for host and guest	
			$esxhost_cred = $arr_hostcred | Select-Object Credentials,HostName | ? {$_.HostName -eq $esxhost}
			$HostCred = $esxhost_cred.Credentials
			$timestamp = gettimestamp
			"$timestamp : Connecting to Host: $esxhost" | Out-File $logfile -Append
			write-host "Connecting to Host: $esxhost" -ForegroundColor Green
			$HostConnection = Connect-VIServer -Server $esxhost -Credential $HostCred
			While (!$HostConnection)
			{
				write-host "Error connecting to ESX Host $esxhost, check username and password!"-ForegroundColor Yellow
				$timestamp = gettimestamp
				"$timestamp : ERROR: Could not connect to ESX Host $esxhost. Check username and password" | Out-File $logfile -Append
				$HostCred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for ESX Host $esxhost", "", "")
				$HostConnection = Connect-VIServer -Server $esxhost -Credential $HostCred
			}

			#Start the VM
			$timestamp = gettimestamp
			"$timestamp : Starting VM $newvmname" | Out-File $logfile -Append
			write-host "Starting VM $newvmname" -ForegroundColor Green
			Get-VM -Name $newvmname | Start-VM -ErrorAction SilentlyContinue -ErrorVariable E_START_VM
			
			#Answer UUID Change question
			$timestamp = gettimestamp
			"$timestamp : Answering VM copy/move question, choosing:moved" | Out-File $logfile -Append
			write-host "Answering VM copy/move question, choosing:moved" -ForegroundColor Green
			$vm = Get-VM $newvmname | Get-VMQuestion | Set-VMQuestion -Option "*moved*" -Confirm:$false
			write-host "Sleeping 15 seconds" -ForegroundColor Green
			Start-Sleep -Seconds 15
			
			$vmpowerstate = ((Get-VM -Name $newvmname).PowerState)
			While ($vmpowerstate -ne "PoweredOn")
			{
				$timestamp = gettimestamp
				"$timestamp : VM is not powered on yet. Waiting 15 Seconds....." | Out-File $logfile -Append
				write-host "VM is not powered on yet. Assuming that the VM is still in power on process. Waiting 15 Seconds....." -ForegroundColor Green
				write-host "Trying again in 15 seconds..." -ForegroundColor Green
				Start-Sleep -Seconds 15
				$vmpowerstate = ((Get-VM -Name $newvmname).PowerState)
			}
						
			#Change the Port group assignment of any vNIC found
			$timestamp = gettimestamp
			"$timestamp : Changing the vSwitch Port Group for VM: $newvmname to $portgroup" | Out-File $logfile -Append
			write-host "Changing the vSwitch Port Group to $portgroup" -ForegroundColor Green
			$vNICs = Get-NetworkAdapter -VM $newvmname
			Foreach ($item in $vNICs)
			{
				Set-NetworkAdapter -NetworkAdapter $item -NetworkName $portgroup -Connected:$True -Confirm:$False
			}
			write-host "Waiting 5 seconds..." -ForegroundColor Green
			Start-Sleep -Seconds 5
			
			#Loop to wait for VM having the guest OS up 'n running
			$guesttools_state = ((Get-VMGuest -VM $newvmname).State)
			$i_try = 0
			While ((!$guesttools_state) -or ($guesttools_state -ne "Running"))
			{
				If ($i_try -lt 10)
				{
					$timestamp = gettimestamp
					"$timestamp : VMware Tools not running yet. Assuming that the guest is still in boot process. Waiting 15 Seconds....." | Out-File $logfile -Append
					write-host "VMware Tools not running yet. Assuming that the guest is still in boot process. Waiting 15 Seconds....." -ForegroundColor Green
					write-host "Trying again in 15 seconds..." -ForegroundColor Green
					Start-Sleep -Seconds 15
					$guesttools_state = ((Get-VMGuest -VM $newvmname).State)
					$i_try += 1
				}
			}
			
			If (!$GuestCred)
			{
				If ($guestuser -and $guestuserpw)
				{
					$guestuserpw = ConvertFromBase64 $guestuserpw
					$guestuserpw_secure = ConvertTo-SecureString $guestuserpw -asplaintext -force
					$GuestCred = New-Object -typename System.Management.Automation.PSCredential -argumentlist $guestuser,$guestuserpw_secure
				}
			}
			If (!$GuestCred)
			{
				$GuestCred = $Host.UI.PromptForCredential("Please enter credentials", "Enter credentials for Guest: $newvmname", "", "")
			}
						
			#Change the VM's IP configuration
			$timestamp = gettimestamp
			"$timestamp : Changing IP configuration for VM: $newvmname" | Out-File $logfile -Append
			write-host "Changing IP configuration for VM: $newvmname , this can take up to 90 seconds to complete.. please wait..." -ForegroundColor Green
			Start-Sleep 30
			$obj = get-vm $newvmname
			Get-VMGuestNetworkInterface -vm $obj -GuestCredential $guestcred | ? {$_.NetworkAdapter -match 'Network adapter'} | Set-VMGuestNetworkInterface -ip $ipaddr -gateway $gateway -netmask $subnet -dns $pdns -IPPolicy static -GuestCredential $guestcred -ToolsWaitSecs 120
						
			#Perform a final reboot
			$timestamp = gettimestamp
			"$timestamp : Perform a final reboot for VM: $newvmname" | Out-File $logfile -Append
			write-host "Perform a final reboot for VM: $newvmname" -ForegroundColor Green
			Restart-VM -VM $newvmname -Confirm:$false -ErrorAction SilentlyContinue
			
			#Connect back to vCenter
			$timestamp = gettimestamp
			"$timestamp : Connecting back to vCenter" | Out-File $logfile -Append
			Disconnect-VIServer * -Confirm:$false
			$vCenterConnection = Connect-VIServer -Server $VCHost -Credential $vCenterCred -ErrorVariable E_VCENTER_CONNECTION
			Start-Sleep -Seconds 2
		}
	   
	}
	
	$timestamp = gettimestamp
	"$timestamp : ---- BCP Switch Operation Finished ----" | Out-File $logfile -Append
	Read-Host "BCP Switch Finished. Press any key to return to menue"
	MAIN
}
#---------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------
Function BCP_DISCARD_SWITCH()
{
$timestamp = gettimestamp
"$timestamp : ---- BCP Discard Switch Operation Started ----" | Out-File $logfile -Append
#Connecting to vCenter server 
	
	If (!$vCenterConnection)
	{
		If (!$vCenterCred) 
		{
			$vCenterCred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for vCenter", "", "") 
		}
		$vCenterConnection = Connect-VIServer -Server $VCHost -Credential $vCenterCred
	}

	#Read VMs to proceed and go
	$timestamp = gettimestamp
	"$timestamp : Read VMs to proceed" | Out-File $logfile -Append
	$vmlist = Import-CSV $VMImportFile
	foreach ($item in $vmlist) 
	{     
				
		If ($item -notmatch '#')
		{
				#Read out the paramaters from CSV File
				$datacenter = $item.datacenter 
				$bcpcluster = $item.bcp_cluster 
				$bcpdatastore = $item.orig_datastore 
				$vmname = $item.vmname 
				$portgroup = $item.portgroupname 
				$ipaddr = $item.ipaddress -replace '\s',''
				$subnet = $item.subnet -replace '\s',''
				$gateway = $item.gateway -replace '\s',''
				$pdns = $item.pdns -replace '\s',''
			

			#Stop VM
			$newvmname = "$vmname_BCP"
			$timestamp = gettimestamp
			"$timestamp : Stopping VM $newvmname" | Out-File $logfile -Append
			write-host "Stopping VM $newvmname" -ForegroundColor Green
			$vm = get-vm ($vmname+'_BCP') -ErrorAction SilentlyContinue -ErrorVariable E_GET_VM
			If ($vm)
			{
				Stop-VM -VM $vm -Confirm:$false -ErrorAction SilentlyContinue
				#Remove VM from Inventory
				write-host "Stopping VM $newvmname" -ForegroundColor Green
				Remove-VM -VM $vm -Confirm:$false -ErrorAction SilentlyContinue
			}
			Else
			{
				$timestamp = gettimestamp
				"$timestamp : WARNING: VM not found: $newvmname" | Out-File $logfile -Append
				write-host "VM not found: $newvmname" -ForegroundColor Yellow
			}
		}
	}

	
	#Proceed with BCP Storage
	$timestamp = gettimestamp
	"$timestamp : Proceed with BCP Storage cleanup" | Out-File $logfile -Append
	$storageconf = Import-CSV $StorageConfFile
	foreach ($item in $storageconf) 
	{     
				
		If ($item -notmatch '#')
		{
				#Read out the paramaters from CSV File
				$bcpcluster = $item.bcp_cluster 
				$bcpdatastore = $item.orig_datastore 
				$bcp_nas_filer = $item.bcp_nasfiler 
				$bcp_nas_lun = $item.bcp_naslun 
				$bcp_igroup_name = $item.iscsi_igroupname 
				$bcp_vol = $bcp_nas_lun.Split("/")[2] 
				$clusterhosts = Get-Cluster $bcpcluster | Get-VMHost
					
			
			#Resyncing the snapmirror
			If (!$NASConnection)
			{
				If (!$NACred)
				{
						If ($nasuser -and $nasuserpw)
						{
							$nasuserpw = ConvertFromBase64 $nasuserpw
							$nasuserpw_secure = ConvertTo-SecureString $nasuserpw -asplaintext -force
							$NACred = New-Object -typename System.Management.Automation.PSCredential -argumentlist $nasuser,$nasuserpw_secure
						}
				}
					If (!$NACred) 
					{
						$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter credentials for NetApp Filer: $bcp_nas_filer", "", "") 
						write-host "Connecting to BCP Filer $bcp_nas_filer" -ForegroundColor Green
						$timestamp = gettimestamp
						"$timestamp : Connecting to BCP Filer $bcp_nas_filer" | Out-File $logfile -Append
					}
						Switch ($NAPort)
							{
								"80" 
									{
										$NASConnection = Connect-NaController $bcp_nas_filer -HTTP -Credential $NACred 
										While (!$NASConnection)
										{
											write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
											$timestamp = gettimestamp
											"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
											$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
											$NASConnection = Connect-NaController $bcp_nas_filer -HTTP -Credential $NACred 
										}
									}
								"443" 
									{
										$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
										While (!$NASConnection)
										{
											write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
											$timestamp = gettimestamp
											"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
											$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
											$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
										}
									}
								"135" 
									{
										$NASConnection = Connect-NaController $bcp_nas_filer -RPC -Credential $NACred 
										While (!$NASConnection)
										{
											write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
											$timestamp = gettimestamp
											"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
											$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
											$NASConnection = Connect-NaController $bcp_nas_filer -RPC -Credential $NACred
										}
									}
								Default 
									{
										$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
										While (!$NASConnection)
										{
											write-host "Error connecting to netapp filer $bcp_nas_filer, check username and password!"-ForegroundColor Yellow
											$timestamp = gettimestamp
											"$timestamp : ERROR: Could not connect to netapp filer $bcp_nas_filer. Check username and password" | Out-File $logfile -Append
											$NACred = $Host.UI.PromptForCredential("Please enter credentials", "Enter your credentials for netapp filer $bcp_nas_filer", "", "")
											$NASConnection = Connect-NaController $bcp_nas_filer -HTTPS -Credential $NACred 
										}
									}
							}
			}
		}
		
		If ($bcpdatastore -match 'ISCSI')
		{
			#Un-Mapping LUNs from igroup
			$timestamp = gettimestamp
			"$timestamp : unmapping $bcp_nas_lun from iGROUP $bcp_igroup_name" | Out-File $logfile -Append
			write-host "unmapping $bcp_nas_lun from iGROUP $bcp_igroup_name" -ForegroundColor Green
			Remove-NaLunMap -Path $bcp_nas_lun -InitiatorGroup $bcp_igroup_name -ErrorAction SilentlyContinue -ErrorVariable E_MAP_LUN | Out-Null
		}
		Elseif ($bcpdatastore -match 'NFS')
		{
			#Un-Mapping NFS Datastores
			$clusterhosts = Get-Cluster $bcpcluster | Get-VMHost
			Foreach ($item in $clusterhosts)
			{
				$timestamp = gettimestamp
				"$timestamp : unmapping $bcp_nas_lun" | Out-File $logfile -Append
				write-host "unmapping $bcp_nas_lun" -ForegroundColor Green
				Remove-Datastore -VMHost $item.Name -Datastore "snap-$bcpdatastore" -Confirm:$false
			}
		}
			
		$mirrorstate = (Get-NaSnapmirror | where { $_.DestinationLocation -match "$bcp_vol"}).State
		If ($mirrorstate -match "broken")
		{
			$timestamp = gettimestamp
			"$timestamp : Rescync snapmirror to destination volume: $bcp_vol on $bcp_nas_filer" | Out-File $logfile -Append
			write-host "Rescync snapmirror to destination volume: $bcp_vol on $bcp_nas_filer" -ForegroundColor Green
			Invoke-NaSnapmirrorResync -Destination $bcp_vol -Confirm:$false | Out-Null
		}
		Else
		{
			$timestamp = gettimestamp
			"$timestamp : Volume  $bcp_vol is already in Syncing state." | Out-File $logfile -Append
			write-host "Volume  $bcp_vol is already in Syncing state." -ForegroundColor Green
		}
			
		
		Foreach ($item in $clusterhosts)
		{
			
			#Rescanning All ESX host's storage adapter
			$timestamp = gettimestamp
			"$timestamp : Rescanning storage adapters on $item" | Out-File $logfile -Append
			write-host "Rescanning storage adapters on $item" -ForegroundColor Green
			Get-VMHostStorage -VMHost $item.Name -RescanAllHBA:$True -RescanVMFS:$True | Out-Null
		}
	}
	$timestamp = gettimestamp
	"$timestamp : ---- BCP Discard Finished ----" | Out-File $logfile -Append
	Read-Host "BCP Discard Finished. Press any key to return to menue" 
	MAIN
}
#---------------------------------------------------------------------------------------


#---------------------------------------------------------------------------------------
function MAIN()
{
	#Display Menue
	#CLS
	
	Write-Host "=========================================================================" -ForegroundColor White
	write-host "            vSphere BCP Switch Tool          (C)2011 / Michael Rueefli   " -ForegroundColor Yellow
	Write-Host "=========================================================================" -ForegroundColor White
	Write-Host ""
	Write-Host ""
	Write-Host "Please make your selection:" -ForegroundColor Gray
	Write-Host ""
	Write-Host "	[1] Switch to BCP Site " 
	Write-Host "	[2] Discard Changes made by last BCP Switch " 
	Write-Host "	[3] Show current configuration" 
	write-Host "	[4] Edit storage config" 
	Write-Host "	[5] Edit VM config" 
	Write-Host ""
	Write-Host "	[q] Exit " 
	Write-Host ""
	
	#get userinput
	$userinput = Read-Host "type a number 1-3 and press [ENTER]"
	
	#select function to execute
	switch($userinput)
	{
		"1" {BCP_SWITCH}
		"2" {BCP_DISCARD_SWITCH}
		"3" {BCP_SHOW_CONFIG}
		"4" {BCP_EDIT_STORAGE_CONFIG}
		"5" {BCP_EDIT_VM_CONFIG}

		"q" {"You have chosen to quit....."; start-sleep 1; exit}
		default {Write-Host "Unknown Option selected, returning to main menue" ; start-sleep 1 ; main }
	}

}
#--------------------------------------------------------------------------------------------------------------


#Calling Main Function to open Menue
MAIN
