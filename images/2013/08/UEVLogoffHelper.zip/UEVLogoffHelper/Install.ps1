﻿


$ErrorActionPreference = "Stop"

function func_CheckIfAdmin  
{  
    $user = [Security.Principal.WindowsIdentity]::GetCurrent();
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)  
}

Function func_writeregvalue()
{
 param([STRING]$keyname,[STRING]$valuename,[STRING]$value,[STRING]$type="String")
 If (!(Test-Path -Path $keyname))
 {
  Write-Debug "Key name: $keyname not found."
 }
 If ((Get-ItemProperty -path $keyname -Name $valuename -ea SilentlyContinue))
 {
  Set-ItemProperty $keyname -Name $valuename -Value $value -Type $type -Force
 }
 Else
 {
  New-ItemProperty $keyname -Name $valuename -Value $value -Type $type
 }
}


Function func_checkpX64latform
{
    If ($env:PROCESSOR_ARCHITECTURE -match 'AMD64')
    {
        return $true
    }
    Else
    {
        return $false
    }
}


Write-Host "******************************************"
Write-Host "UEVLogoffHelper Install Script"
write-Host "(C) 2013 / Michael Rüefli"
Write-Host "******************************************"

#Check Platform
If (func_checkpX64latform)
{
    $programdir = ${env:ProgramFiles(x86)}
}
Else
{
    $programdir = $env:ProgramFiles
}


#Check if we run in elevated mode
If (!(func_CheckIfAdmin))
{
    Write-Warning "The script has to be run with administrative privileges!"
    break
}


#Get the current execution path
$runpath = split-path -parent $MyInvocation.MyCommand.Definition

#Copy Binary
If (!(test-path -path "$programdir\UEVLogoffHelper"))
{
    New-Item -ItemType Directory -Path $programdir\UEVLogoffHelper | out-null
}
Copy-Item "$runpath\UEVLogoffHelper.exe" "$programdir\UEVLogoffHelper\" -Force

#Register Event Source
New-EventLog -LogName Application -Source UEVLogoffHelper -ErrorAction SilentlyContinue


#Register the tray app to run on winlogon initialization
func_writeregvalue -keyname "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -valuename "UEVLogoffHelper" -value "$programdir\UEVLogoffHelper\UEVLogoffHelper.exe" | out-null


Write-Host "Script finished successfully." -fore Green
Write-Host "UEVLogoffHelper will be startet upon next Logon"
