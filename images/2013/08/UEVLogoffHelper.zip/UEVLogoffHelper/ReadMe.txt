=======================================
UE-V Logoff Helper
Version 1.0
Written by Michael R�efli
Email: drmiru(at)hotmail.com
Twitter: @DRMIRU
Blog: www.miru.ch
=======================================

Purpose
--------------------------
The tool runs per user session and ensures UE-V application settings for running applications 
are synced back to the central location store on logoff.

Installation
--------------------------
Run the Install.ps1 script within a Powershell Session with elevated privileges.
You might have to change your Powershell Execution Policy, unblock the binary and scripts as after downloading the 
files, your OS will recognize them as "remote" files.
The Application gets copied to the Program Files directory and registered under HKLM\Software\Microsoft\Windows\Current Version\Run

Removal
--------------------------
Run the UnInstall.ps1 script within a Powershell Session with elevated privileges

Known Limitations
--------------------------
� Internet Explorer Settings are not synced if IE is open during logoff
� If applications have an active �save-as� dialog the sync process might be interrupted
� As by design, applications which are not form based (GUI less) don�t respond to CloseMainForm() method and are therefore not captured by the tool

DISCLAIMER
--------------------------
This software is provided �as is," and you use the software at your own risk.
I make no warranties as to performance, merchantability, fitness for a particular purpose, or any other warranties whether expressed or implied.
No oral or written communication from or information provided shall create a warranty.
Under no circumstances will I be liable for direct, indirect, special, incidental, or consequential damages resulting from the use, misuse, or inability to use this software.
