﻿


$ErrorActionPreference = "Stop"

function func_CheckIfAdmin  
{  
    $user = [Security.Principal.WindowsIdentity]::GetCurrent();
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)  
}

Function func_deleteregvalue()
{
 param([STRING]$keyname,[STRING]$valuename)
 Remove-ItemProperty -path $keyname -Name $valuename -ErrorAction SilentlyContinue 
}



Function func_checkpX64latform
{
    If ($env:PROCESSOR_ARCHITECTURE -match 'AMD64')
    {
        return $true
    }
    Else
    {
        return $false
    }
}



Write-Host "******************************************"
Write-Host "UEVLogoffHelper Removal Script"
write-Host "(C) 2013 / Michael Rüefli"
Write-Host "******************************************"

#Check Platform
If (func_checkpX64latform)
{
    $programdir = ${env:ProgramFiles(x86)}
}
Else
{
    $programdir = $env:ProgramFiles
}



#Check if we run in elevated mode
If (!(func_CheckIfAdmin))
{
    Write-Warning "The script has to be run with administrative privileges!"
    break
}


#Get the current execution path
$runpath = split-path -parent $MyInvocation.MyCommand.Definition

#Stop Process
Get-Process UEVLogoffHelper -ErrorAction SilentlyContinue | stop-process 

#Remove Binary
If (!(test-path -path "$programdir\UEVLogoffHelper"))
{
    Remove-Item -Recurse -Path "$programdir\UEVLogoffHelper" -Force
}

#Un-Register Event Source
Remove-EventLog -Source UEVLogoffHelper -ErrorAction SilentlyContinue


#Un-Register the tray app to run on Logon
func_deleteregvalue -keyname "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -valuename "UEVLogoffHelper" | out-null


Write-Host "Script finished successfully." -fore Green
Write-Host "UEVLogoffHelper has been removed from your system"
