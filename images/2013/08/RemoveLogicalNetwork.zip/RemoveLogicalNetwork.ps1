<#
.Synopsis
   Remove a Logical Network in SCVMM
.DESCRIPTION
   Removes a logical Network in SCVMM with all depending components
.EXAMPLE
   RemoveLogicalnetwork.ps1 -LogicalNetworkName "LNET_PROD-Datacenter1"
.INPUTS
   Name of Logical network as String
.OUTPUTS
   Information and Errors on Console
.NOTES
   Version 1.0
   Written by Michael R�efli (http://www.miru.ch)
   Date: 07.08.2013
   The logical switch object is left behind as I thought it is too risky to flush the whole object
#>
[CmdletBinding(SupportsShouldProcess=$true, 
                  PositionalBinding=$false,
                  HelpUri = 'http://www.miru.ch/',
                  ConfirmImpact='Medium')]
[OutputType([String])]
 Param
(
    # Logical network name as String
    [Parameter(Mandatory=$true, 
    ValueFromPipeline=$true,
    ValueFromPipelineByPropertyName=$true, 
    ValueFromRemainingArguments=$false, 
    Position=0)]
    [ValidateNotNull()]
    [ValidateNotNullOrEmpty()]
    $LogicalNetworkName
)

#Stop on any error
$ErrorActionPreference = "Stop"

#Import VMM Module
If (!(Get-Module VirtualMachineManager))
{
    Import-Module VirtualMachineManager
}


#Collect Information
Write-Host "Collecting Information" -ForegroundColor Cyan
$lnet = Get-SCLogicalNetwork -Name $LogicalNetworkName
If (!$lnet)
{
    write-warning "Logical Network with Name: $LogicalNetworkName not found!. Aborting"
    break
}
$lnetdefs = Get-SCLogicalNetworkDefinition | ? {$_.LogicalNetwork -eq $LogicalNetworkName}
$uplinkportprofs = Get-SCNativeUplinkPortProfile | ? {$_.LogicalNetworkDefinitions.LogicalNetwork -match $LogicalNetworkName} 
$vmnets = Get-SCVMNetwork | ? {$_.LogicalNetwork -eq $LogicalNetworkName}
$ippools = $lnetdefs | % {Get-SCStaticIPAddressPool -LogicalNetworkDefinition $_}


#Removing Logical Switches configured with Logical Network from All Hyper-V Hosts
Write-Host "Removing Logical Switches configured with Logical Network: $LogicalNetworkName from All Hyper-V Hosts" -ForegroundColor Cyan 
Get-SCVMhost | Get-SCVirtualNetwork | ? {$_.LogicalNetworks.Name -eq $LogicalNetworkName} | Remove-SCVirtualNetwork 

#Removing IP Pools from Logical Network
Write-Host "Removing IP Pools depending on Logical Network" -ForegroundColor Cyan
$ippools | % {Remove-SCStaticIPAddressPool $_}

#Remove VM Networks mapped to logical Network
Write-Host "Removing VM Networks depending on Logical Network" -ForegroundColor Cyan
$vmnets | % {Remove-SCVMNetwork $_}

#Remove Native Uplink Port Profiles Mappings from Logical Switches
Write-Host "Removing Native Uplink Port Profiles Mappings from Logical Switches" -ForegroundColor Cyan
Foreach ($upp in $uplinkportprofs)
{
    Get-SCUplinkPortProfileSet | ? {$_.NativeUplinkPortProfile -match $upp.Name} | Remove-SCUplinkPortProfileSet
}

#Remove Native Uplink Port Profiles mapped to Logical Network Definitions
Write-Host "Native Uplink Port Profiles mapped to Logical Network Definitions" -ForegroundColor Cyan
$uplinkportprofs | % {Remove-SCNativeUplinkPortProfile $_}

#Remove Logical Network Definitions (Network Sites)
Write-Host "Logical Network Definitions (Network Sites)" -ForegroundColor Cyan
$lnetdefs | % {Remove-SCLogicalNetworkDefinition $_}

#Finally Remove the Logical Network
Write-Host "Now we can delete the Logical Network: $LogicalNetworkName" -ForegroundColor Cyan
$lnet | Remove-SCLogicalNetwork

Write-Host "Done!" -ForegroundColor Green
