#############################################################################################
# Scriptname: 	AppConf.ps1
# Author:		Michael R�efli
# Description:	Powershell script which is intended to be executed within an 
#				App-V OSD pre-launch process to set application environment settings
#				which are saved within an XML file.
#
# Version:		0.9
# Usage:
#
# History:
#############################################################################################

# don't create separate threads while processing to save memory
$Host.Runspace.ThreadOptions=�ReuseThread�

#Evaluate arguments
$i= 0
$argcount = ($args).count
while ($i -lt $argcount) 
{
	#If -v is passed as argument activate verbose mode and logging
	if ($args[$i] -eq "-v")
	{
		$blnverbose = $True
	}
	$i++
}

Function write_log($logtext)
{
	If ($blnverbose -eq $True)
	{
		$appname = $ENV:APPV_VAPPNAME
		$logpath = $env:TEMP
		$logfile_timestamp = get-date -uformat "%d-%m-%Y"
		$log_timestamp = get-date -uformat "%H:%M:%S %A,%d %b %Y"
		$logfile = $logpath + '\' + $appname +'-AppConf-'+$logfile_timestamp+'.log'
		"$log_timestamp : $logtext" | out-file $logfile -append
	}
}


Function write_reg_val($key,$valname,$val,$valtype)
{
	trap [Exception]{ $_.Message ; continue }
	
	#Check if Key exists, if not stop
	If ((Test-Path -path "$key") -ne $True) 
	{ 
		write-warning "$key does not exist in the App-V bubble, skipping registry operation"
		write_log "WARNING: $key does not exist in the App-V bubble, skipping registry operation"		
		break
	}
	
	#Delete Value if exists
	$valex = Get-ItemProperty -Path "$key" -Name "$valname" -ErrorAction SilentlyContinue
	If ($valex)
	{
		write_log "INFO: Removing existing Valuename $key\$valname"
		remove-ItemProperty "$key" "$valname" | out-null
	}
	#write new Value
	write_log "INFO: Writing new Valuename $key\$valname with Value: $val"
	New-ItemProperty "$key" -name "$valname" -value "$val" -propertyType $valtype | out-null
}

function find_replace($file,$findstr,$replacestr)
{
trap [Exception]{ $_.Message ; continue }
if ($args[0] -eq "-h") {
	Write-Host "usage: find_replace <Filename>,<Find-String>,<Replace-Sring>,[-o <NewOutputFile>],[-e <Encoding Ascii,BigEndianUnicode,Byte,String,Unicode,Unknown,UTF7,UTF8>]"
	break
	}
	
	If ((Test-Path -Path $file) -ne $true)
	{
		write_log "WARNING: Source file $file not found. skipping find/replace operation"
		Write-Warning "File $file not found. skipping find/replace operation"
		break
	}
	$i= 0
	$argcount = ($args).count
	while ($i -lt $argcount) {
		if ($args[$i] -eq "-o"){
			$newfile = $args[$i+1]
			}
		if ($args[$i] -eq "-e"){
			$encoding = $args[$i+1]
			}
		$i++
		}
	if (($newfile) -and ($encoding)){
		$input =  Get-Content $file -Encoding $encoding
		$output = $input -replace($findstr,$replacestr)
		write_log "INFO: Replacing String $findstr with $replacestr to new File $newfile with encoding $encoding"
		Set-Content $newfile $output -Encoding $encoding
		}
	elseif ($newfile){
		$input =  Get-Content $file 
		$output = $input -replace($findstr,$replacestr)
		write_log "Replacing String $findstr with $replacestr to new File $newfile"
		Set-Content $newfile $output 
		}
	elseif ($encoding){
		$input =  Get-Content $file -Encoding $encoding
		$output = $input -replace($findstr,$replacestr)
		write_log "INFO: Replacing String $findstr with $replacestr in File $file with encoding $encoding"
		Set-Content $file $output -Encoding $encoding
		}
	elseif ($argcount -eq 0) {
		$input =  Get-Content $file
		$output = $input -replace($findstr,$replacestr)
		write_log "INFO: Replacing String $findstr with $replacestr in File $file"
		Set-Content $file $output
		}		
}	

Function file_copy($src,$dst,$overwrt,$recurse)
{
	trap [Exception]{ $_.Message ; continue }
	#Check if source file exists, if not skip
	If (!(Test-Path "$src")) 
	{ 
		write_log "WARNING: File: $src does not exist. Skipping current operation"
		write-warning "File: $src does not exist. Skipping current operation"
	}
	Else
	{
		#Copy the file
		If ($recurse -eq "yes" -and $overwrt -eq "yes")
		{
			write_log "INFO: Recursive copy all files from $src to $dst with override"
			Copy-Item $src $dst -Force -Confirm:$false -Recurse 
		}
		Elseif ($recurse -eq "no" -and $overwrt -eq "yes")
		{
			write_log "Copy $src to $dst"
			Copy-Item $src $dst -Force -Confirm:$false
		}
		Elseif ($recurse -eq "yes" -and $overwrt -eq "no")
		{
			write_log "INFO: Recursive copy all files from $src to $dst without override"
			Copy-Item $src $dst -Recurse
		}
	}
}

#Instantiate XML reader
trap [System.Xml.XmlException]
{
	write_log "ERROR: Reading XML failed. Check XML Syntax: $_.Exception.Message"
	write-warning "ERROR: Reading XML failed. Check XML Syntax: $_.Exception.Message"
	break 
}

[System.Xml.XmlDocument] $xd = new-object System.Xml.XmlDocument
$file = ($args[0])
If (!$file)
{
	write_log "WARNING: XML File $file not found or argument not passed. exit now"
	Write-Warning "XML File not found or argument not passed.!"
	break
}

#Load the XML document
$xd.load($file) 
#get XML nodelist
$nodelist = $xd.selectnodes("/config/param") 
foreach ($confignode in $nodelist) 
{
  $type = $confignode.getAttribute("type")
  $inputsNode = $confignode.selectSingleNode("data")
  Switch ($type){
  	"REG_VAL"
	{
		"Registry Operation"
		$keyname = $inputsNode.selectSingleNode("keyname").get_InnerXml()
		$valname = $inputsNode.selectSingleNode("valname").get_InnerXml()
		$value = $inputsNode.selectSingleNode("value").get_innerXml()
		$valtype = $inputsNode.selectSingleNode("valtype").get_innerXml()
		write_reg_val $keyname $valname $value $valtype
	}
	"FIND_REPLACE"
	{
		"Find Replace operation"
		$filename = $inputsNode.selectSingleNode("filename").get_InnerXml()
		$findstring = $inputsNode.selectSingleNode("findstr").get_InnerXml()
		$replacestring = $inputsNode.selectSingleNode("replstr").get_innerXml()
		#$encoding = $inputsNode.selectSingleNode("encoding").get_innerXml()
		find_replace $filename $findstring $replacestring
	}
	"COPY_FILES"
	{
		"Copy data operation"
		$source = $inputsNode.selectSingleNode("source").get_InnerXml()
		$destination = $inputsNode.selectSingleNode("destination").get_InnerXml()
		$overwrite = $inputsNode.selectSingleNode("overwrite").get_InnerXml()
		$recursive = $inputsNode.selectSingleNode("recursive").get_InnerXml()
		file_copy $source $destination $overwrite $recursive
	}
  }
}
