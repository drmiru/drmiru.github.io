#####################################################
AppConf for App-V

Author: Michael Rueefli
#####################################################

Intention
---------
Simplify the OSD scripting by simply calling a generic
script that reads an XML file and sets specific registry and 
file settings for the App-V package.

Current Functions
-----------------
- Set registry settings within the virtual bubble
- Replace text file content
- Copy / replace files and folders


Components
----------
AppConf.ps1 (powershell script to be called from OSD file)
App1.xml (example config file)
WinSCP.osd (example OSD with script call to the powershell script)


Usage
-----
Add a script event to your OSD file.

<DEPENDENCY>
  <SCRIPT TIMING="PRE" EVENT="LAUNCH" WAIT="TRUE" PROTECT="TRUE"> 
    <SCRIPTBODY>
	powershell \\\\appvserver\\AppVContent\\Scripts\\AppConf.ps1 \\\\appvserver\\AppVContent\\Scripts\\winscp.xml -v
    </SCRIPTBODY> 
  </SCRIPT>
  <CLIENTVERSION VERSION="3.1.2.2"/>
</DEPENDENCY> 


Debugging
---------
Adding -v argument generates a logfile within the current %temp% directory

Bug reporting
-------------
Please report bugs to: michael.rueefli@inserto.ch