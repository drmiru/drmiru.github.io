﻿namespace VDISecureCenterTicketFRM
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBox_Intention = new System.Windows.Forms.TextBox();
            this.btn_ok = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_intention = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbox_custdata = new System.Windows.Forms.ComboBox();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtBox_Intention
            // 
            this.txtBox_Intention.AcceptsReturn = true;
            this.txtBox_Intention.AcceptsTab = true;
            this.txtBox_Intention.Location = new System.Drawing.Point(62, 114);
            this.txtBox_Intention.Multiline = true;
            this.txtBox_Intention.Name = "txtBox_Intention";
            this.txtBox_Intention.Size = new System.Drawing.Size(544, 133);
            this.txtBox_Intention.TabIndex = 0;
            this.txtBox_Intention.TextChanged += new System.EventHandler(this.txtBox_Intention_TextChanged);
            // 
            // btn_ok
            // 
            this.btn_ok.BackColor = System.Drawing.Color.PaleGreen;
            this.btn_ok.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ok.Location = new System.Drawing.Point(62, 565);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(145, 23);
            this.btn_ok.TabIndex = 1;
            this.btn_ok.Text = "OK, go ahead";
            this.btn_ok.UseVisualStyleBackColor = false;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "Access to productive Systems hosting customer date",
            "Access to Test Systems hosting anonymous customer data",
            "Infrastructure Operation / Management",
            "Operations / Task Control",
            "Deployment of new services / Installation",
            "Documentation"});
            this.listBox1.Location = new System.Drawing.Point(62, 295);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(467, 82);
            this.listBox1.TabIndex = 2;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 276);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "Choose access type";
            // 
            // lbl_intention
            // 
            this.lbl_intention.AutoSize = true;
            this.lbl_intention.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_intention.Location = new System.Drawing.Point(62, 95);
            this.lbl_intention.Name = "lbl_intention";
            this.lbl_intention.Size = new System.Drawing.Size(544, 18);
            this.lbl_intention.TabIndex = 6;
            this.lbl_intention.Text = "Enter your intention for this access (describe what you are going to do)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(62, 405);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 14);
            this.label2.TabIndex = 7;
            this.label2.Text = "Will any customer data be accessed?";
            // 
            // cbox_custdata
            // 
            this.cbox_custdata.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbox_custdata.FormattingEnabled = true;
            this.cbox_custdata.Items.AddRange(new object[] {
            "yes",
            "no"});
            this.cbox_custdata.Location = new System.Drawing.Point(65, 423);
            this.cbox_custdata.Name = "cbox_custdata";
            this.cbox_custdata.Size = new System.Drawing.Size(91, 21);
            this.cbox_custdata.TabIndex = 8;
            this.cbox_custdata.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Location = new System.Drawing.Point(366, 564);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(163, 23);
            this.btn_cancel.TabIndex = 9;
            this.btn_cancel.Text = "Cancel, log me off";
            this.btn_cancel.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(61, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(418, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "LGT VDI & Secure Center RAS Ticket Opening Form";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(65, 487);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(92, 20);
            this.textBox1.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(62, 457);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 26);
            this.label4.TabIndex = 12;
            this.label4.Text = "Existing Incident Number\r\n(optional)";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1432, 830);
            this.ControlBox = false;
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.cbox_custdata);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_intention);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.txtBox_Intention);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximumSize = new System.Drawing.Size(1500, 1200);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1438, 858);
            this.Name = "frm_main";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Ticket opening";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBox_Intention;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_intention;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbox_custdata;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
    }
}

