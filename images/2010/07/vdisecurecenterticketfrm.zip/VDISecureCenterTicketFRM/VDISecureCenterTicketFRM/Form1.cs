﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Diagnostics;



namespace VDISecureCenterTicketFRM
{
    public partial class frm_main : Form
    {
        public frm_main()
        {
            InitializeComponent();
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            string text = txtBox_Intention.Text;
            string accesstype = listBox1.Text;
            string username = System.Windows.Forms.SystemInformation.UserName;

            
            XmlTextWriter textWriter = new XmlTextWriter("D:\\myXmFile.xml", null) ;
            textWriter.WriteStartDocument();
                textWriter.WriteStartElement("DATA");
                textWriter.WriteStartElement("LoginName", ""); textWriter.WriteString(username);
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("IntentionText", ""); textWriter.WriteString(text);
                textWriter.WriteEndElement();
                textWriter.WriteStartElement("AccessType", ""); textWriter.WriteString(accesstype);
                textWriter.WriteEndElement();  
                textWriter.WriteStartElement("CustomerData", ""); textWriter.WriteString(cbox_custdata.Text);
                textWriter.WriteEndElement();
           
            textWriter.WriteEndDocument();
            textWriter.Close();

            if (text.Length > 5)
            {
                if (accesstype.Length > 0)
                {
                    if (cbox_custdata.Text.Length > 0)
                    {
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("You must select if customer data will be accessed or not", "Missing values", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                {
                    MessageBox.Show("You must select a type of access", "Missing values", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Please enter a text that makes sense and describes what you're going zo do","Missing values", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            
            
        }

        private void txtBox_Intention_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void rd_btn_no_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rd_btn_yes_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void frm_main_Load(object sender, EventArgs e)
        {

        }
    }
}
